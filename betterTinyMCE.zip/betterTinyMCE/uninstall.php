<?php

/*
* Uninstall plugin.
*/

defined('ABSPATH') or die( "Bye bye" );
if(!defined('WP_UNINSTALL_PLUGIN'))
{
    die;
}
?>
